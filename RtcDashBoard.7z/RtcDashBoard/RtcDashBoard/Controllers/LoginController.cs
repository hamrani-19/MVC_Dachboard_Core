﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RtcDashBoard.Context;
using RtcDashBoard.Models;

namespace RtcDashBoard.Controllers
{
    public class LoginController : Controller
    {
        dataBaseContext _dataBaseContext = new dataBaseContext();

        [Route("")]
        [Route("login")]
        [Route("login.do")]
        public IActionResult Login()
        {
            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("username")))
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View();
            }

        }

        [HttpPost]
        public IActionResult Authentification(string DAS, string password)
        {
            SQLUsersData sqlData = new SQLUsersData(_dataBaseContext);
            var user = sqlData.Get(DAS);

            if (user != null && ModelState.IsValid)
            {
                //var dbPass = SecurePasswordHasher.DecryptRijndael(user.Password, SecurePasswordHasher.slat);
                if ("1234" == password)
                {
                    HttpContext.Session.SetString("username", DAS+" / "+user.Name);
                    var role = sqlData.GetRole(user);
                    HttpContext.Session.SetString("Role", role.RoleName);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ViewBag.errorMessage = "Invalid Password !";
                    ModelState.AddModelError(string.Empty, ViewBag.errorMessage);
                    return View("Login");

                }
            }
            else
            {
                ViewBag.errorMessage = "You don't have an account ! Make sure to inform your manager for the creation";
                ModelState.AddModelError(string.Empty, ViewBag.errorMessage);
                return View("Login");
            }

        }

        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [Route("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("username");
            return RedirectToAction(nameof(Login));
        }


    }
}