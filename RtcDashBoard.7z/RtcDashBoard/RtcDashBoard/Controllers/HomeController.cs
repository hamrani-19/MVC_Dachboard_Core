﻿using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RtcDashBoard.Models;
using RestSharp;
using System.Net;
using RtcDashBoard.ClientServer;
using System.Xml;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Authorization;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.Entity;
using System.Linq;

namespace RtcDashBoard.Controllers
{
    public class HomeController : Controller
    {
        #region variables
        private readonly Dictionary<string, string> parameters = new Dictionary<string, string>
        {
            { "j_username", "A696302" },
            { "j_password", "Allahoakbar2019" }
        };
        private readonly string urlAuth = "https://rtc5a.gsissc.myatos.net/rtc5a/web/j_security_check";
        private readonly string proxy = "http://193.56.47.8:8080";
        private readonly string auroTicketsUrl = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.ticket]/(id|summary|priority/name|severity/name|timeSpent|owner/name|creationDate|projectArea/name|itemHistory/state/name)&size=0&pos=0";
        CookieContainer _ckContainer = new CookieContainer();
        RestClient client = new RestClient();
        RestRequest request = new RestRequest();
        dataBaseContext _dataBaseContext = new dataBaseContext();

        #endregion
        private readonly dataBaseContext _context;

        public HomeController(dataBaseContext context)
        {
            _context = context;
        }

        [Route("Home")]
        public IActionResult Index()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                #region urlStats
                string ticket_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                   "[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.ticket]&size=0&pos=0";
                string defects_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                   "[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.defect]&size=0&pos=0";
                string activities_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                   "[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.activite]&size=0&pos=0";
                string unassign_ticket_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                       "[projectArea/name=FR_BEZ_CSI_AURO and owner/name=Unassigned and " +
                                            "type/id=fr.atos.workitem.auro.ticket]&size=0&pos=0";
                string unassign_defects_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                       "[projectArea/name=FR_BEZ_CSI_AURO and owner/name=Unassigned and " +
                                             "type/id=fr.atos.workitem.auro.defect]&size=0&pos=0";
                string unassign_activities_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                               "[projectArea/name=FR_BEZ_CSI_AURO and owner/name=Unassigned and " +
                                        "type/id=fr.atos.workitem.auro.activite]&size=0&pos=0";

                #endregion

                RestClientExtension restClientExtensions = new RestClientExtension(_ckContainer, client, request);
                List<string> countResult = new List<string>();
                IRestResponse authentificationResult = restClientExtensions.PostQuery(urlAuth, proxy, parameters);
                if (authentificationResult.IsSuccessful)
                {
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(ticket_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(defects_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(activities_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(unassign_ticket_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(unassign_defects_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(unassign_activities_query_str, proxy).Content.ToString()));

                }
                ViewBag.countResult = countResult;
                return View();
            }

        }
        public IActionResult GetTickets()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                RestClientExtension restClientExtensions = new RestClientExtension(_ckContainer, client, request);
                IRestResponse getTickets = null;
                IRestResponse authentificationResult = restClientExtensions.PostQuery(urlAuth, proxy, parameters);
                if (authentificationResult.IsSuccessful)
                {
                    getTickets = restClientExtensions.GetQuery(auroTicketsUrl, proxy);
                }
                if (getTickets.IsSuccessful)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(getTickets.Content.ToString());
                    XmlElement root = doc.DocumentElement;
                    XmlNodeList nodes = root.SelectNodes("workItem"); // You can also use XPath here
                    ViewBag.ticketsData = nodes;

                }
                else
                {
                    ViewBag.ticketsData = "No data retrived from RTC";
                }
                return View("../Tickets/TicketsView");
            }
            
        }

        public string getXmlNodecount(string xmlContent)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlContent);
            XmlElement root = doc.DocumentElement;
            XmlNodeList nodes = root.SelectNodes("workItem");

            return nodes.Count.ToString();
        }

        [Route("AllUsers")]
        public IActionResult AllUsers()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                IEnumerable<Users> listOFUsers = _context.Users.Where(u => u.Active != "0").ToList();
                ViewBag.AllUsers = listOFUsers;
                return View("../Users/Index");
            }
        }

        [Route("AddUser")]
        [Route("NewUser")]
        public IActionResult AddUser()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                ViewBag.ROLE = new SelectList(_context.Role, "RoleId", "RoleName");
                return View("../Users/Create");
            }
        }

        public IActionResult Register([Bind("Das,Name,Email,Active,Password,RoleId")] Users user)
        {

            var pass = SecurePasswordHasher.EncryptRijndael(user.Password, SecurePasswordHasher.slat);
            user.Password = pass.ToString();
            _dataBaseContext.Add(user);
            _dataBaseContext.SaveChanges();

            return RedirectToAction("AllUsers");
        }

        public IActionResult Delete(string DAS)
        {
            if (DAS == null)
            {
                return NotFound();
            }

            var users = _context.Users.Find(DAS);

            if (users == null)
            {
                return NotFound();
            }

            users.Active = "0";
            _context.SaveChanges();

            return RedirectToAction("AllUsers");
        }

       
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
