﻿using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RtcDashBoard.Models;
using RestSharp;
using System.Net;
using RtcDashBoard.ClientServer;
using System.Xml;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.Entity;
using System.Linq;
using System.Xml.Linq;
using System;

namespace RtcDashBoard.Controllers
{
    public class HomeController : Controller
    {
        #region variables
        private readonly Dictionary<string, string> parameters = new Dictionary<string, string>
        {
            { "j_username", "A696302" },
            { "j_password", "Allahoakbar2019" }
        };
        private readonly Dictionary<string, string> parameters2 = new Dictionary<string, string>
        {
            { "OSLC-Core-Version", "2.0" },
            { "Accept", "application/rdf+xml" },
            { "Content-Type", "application/rdf+xml"}
        };
        private readonly string urlAuth = "https://rtc5a.gsissc.myatos.net/rtc5a/web/j_security_check";
        private readonly string proxy = "http://193.56.47.8:8080";
        private readonly string auroTicketsUrl = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.ticket]/(id|summary|priority/name|severity/name|timeSpent|owner/name|creationDate|projectArea/name|itemHistory/state/name)&size=0&pos=0";
        CookieContainer _ckContainer = new CookieContainer();
        RestClient client = new RestClient();
        RestRequest request = new RestRequest();
        dataBaseContext _dataBaseContext = new dataBaseContext();

        #endregion
        private readonly dataBaseContext _context;

        public HomeController(dataBaseContext context)
        {
            _context = context;
        }

        [Route("Home")]
        public IActionResult Index()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                #region urlStats
                string ticket_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                   "[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.ticket]&size=0&pos=0";
                string defects_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                   "[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.defect]&size=0&pos=0";
                string activities_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                   "[projectArea/name=FR_BEZ_CSI_AURO and type/id=fr.atos.workitem.auro.activite]&size=0&pos=0";
                string unassign_ticket_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                       "[projectArea/name=FR_BEZ_CSI_AURO and owner/name=Unassigned and " +
                                            "type/id=fr.atos.workitem.auro.ticket]&size=0&pos=0";
                string unassign_defects_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                                       "[projectArea/name=FR_BEZ_CSI_AURO and owner/name=Unassigned and " +
                                             "type/id=fr.atos.workitem.auro.defect]&size=0&pos=0";
                string unassign_activities_query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/rpt/repository/workitem?fields=workItem/workItem" +
                               "[projectArea/name=FR_BEZ_CSI_AURO and owner/name=Unassigned and " +
                                        "type/id=fr.atos.workitem.auro.activite]&size=0&pos=0";

                #endregion

                RestClientExtension restClientExtensions = new RestClientExtension(_ckContainer, client, request);
                List<string> countResult = new List<string>();
                IRestResponse authentificationResult = restClientExtensions.PostQuery(urlAuth, proxy, parameters);
                if (authentificationResult.IsSuccessful)
                {
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(ticket_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(defects_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(activities_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(unassign_ticket_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(unassign_defects_query_str, proxy).Content.ToString()));
                    countResult.Add(getXmlNodecount(restClientExtensions.GetQuery(unassign_activities_query_str, proxy).Content.ToString()));

                }
                ViewBag.countResult = countResult;
                return View();
            }

        }
        public IActionResult GetTickets()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                RestClientExtension restClientExtensions = new RestClientExtension(_ckContainer, client, request);
                IRestResponse getTickets = null;
                IRestResponse authentificationResult = restClientExtensions.PostQuery(urlAuth, proxy, parameters);
                if (authentificationResult.IsSuccessful)
                {
                    getTickets = restClientExtensions.GetQuery(auroTicketsUrl, proxy);
                }
                if (getTickets.IsSuccessful)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(getTickets.Content.ToString());
                    XmlElement root = doc.DocumentElement;
                    XmlNodeList nodes = root.SelectNodes("workItem"); // You can also use XPath here
                    ViewBag.ticketsData = nodes;

                }
                else
                {
                    ViewBag.ticketsData = "No data retrived from RTC";
                }
                return View("../Tickets/TicketsView");
            }

        }

        public string getXmlNodecount(string xmlContent)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlContent);
            XmlElement root = doc.DocumentElement;
            XmlNodeList nodes = root.SelectNodes("workItem");

            return nodes.Count.ToString();
        }

        [Route("AllUsers")]
        public IActionResult AllUsers()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                IEnumerable<Users> allUsers = _context.Users.Include(u => u.Role).Where(e => e.Active != "0").ToList();
                IEnumerable<Role> allRoles = _context.Role.ToList();

                ViewBag.allUsers = allUsers;
                ViewBag.allRoles = allRoles;

                return View("../Users/Index");
            }
        }

        [Route("AddUser")]
        [Route("NewUser")]
        public IActionResult AddUser()
        {
            if ((HttpContext.Session.GetString("username") == null))
            {
                return RedirectToAction("Login", "Login");
            }
            else
            {
                ViewBag.ROLE = new SelectList(_context.Role, "RoleId", "RoleName");
                return View("../Users/Create");
            }
        }

        public IActionResult Register([Bind("Das,Name,Email,Active,Password,RoleId")] Users user)
        {

            var pass = SecurePasswordHasher.EncryptRijndael(user.Password, SecurePasswordHasher.slat);
            user.Password = pass.ToString();
            _dataBaseContext.Add(user);
            _dataBaseContext.SaveChanges();

            return RedirectToAction("AllUsers");
        }

        public IActionResult Delete([Bind("Das,Name,Email,Active,Password,RoleId")] Users user)
        {
            if (user.Das == null)
            {
                return NotFound();
            }

            var users = _context.Users.Find(user.Das);

            if (users == null)
            {
                return NotFound();
            }

            users.Active = "0";
            _context.SaveChanges();

            return RedirectToAction("AllUsers");
        }

        public IActionResult EditView(string DAS)
        {

            if (DAS == null)
            {
                return NotFound();
            }

            var users = _context.Users.Find(DAS);

            if (users == null)
            {
                return NotFound();
            }

            ViewBag.User = users;
            ViewBag.ROLE = new SelectList(_context.Role, "RoleId", "RoleName");
            return View("../Users/Edit");

        }

        [HttpPost]
        public IActionResult Edit(string DAS, [Bind("Das,Name,Email,Active,Password,RoleId")] Users users)
        {
            if (DAS != users.Das)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _context.Users.Update(users);
                _context.SaveChanges();

            }



            ViewBag.ROLE = new SelectList(_context.Role, "RoleId", "RoleName");
            return RedirectToAction("AllUsers");
        }

        public IActionResult EditTicketView(string ID, string Summary)
        {
            ViewBag.ID = ID;
            ViewBag.Summary = Summary;
            return View("../Tickets/EditTicket");
        }

        [HttpPost]
        public IActionResult EditTicket(string ID, string summary, string resource, string state)
        {
            string query_str = "https://rtc5a.gsissc.myatos.net/rtc5a/resource/itemName/com.ibm.team.workitem.WorkItem/" + ID + "?_action=" + state + "";
            string contributor = @"""https://jts5.gsissc.myatos.net/jts5/users/" + resource.Split('-')[1] + "\"";

            string data = @"<?xml version=""1.0"" encoding=""UTF-8""?>
            <rdf:RDF xmlns:oslc_pl=""http://open-services.net/ns/pl#""
            xmlns:rtc_ext=""http://jazz.net/xmlns/prod/jazz/rtc/ext/1.0/""
            xmlns:rtc_cm=""http://jazz.net/xmlns/prod/jazz/rtc/cm/1.0/""
            xmlns:dcterms= ""http://purl.org/dc/terms/""
            xmlns:oslc_cmx=""http://open-services.net/ns/cm-x#""
            xmlns:acp=""http://jazz.net/ns/acp#""
            xmlns:oslc_cm=""http://open-services.net/ns/cm#""
            xmlns:rdf=""http://www.w3.org/1999/02/22-rdf-syntax-ns#""
            xmlns:oslc=""http://open-services.net/ns/core#"">                                                                                                                     
            <rdf:Description>
            <dcterms:title>{0}</dcterms:title>
            <dcterms:contributor rdf:resource={1}/>
            </rdf:Description>
            </rdf:RDF>";
            data = string.Format(data, summary, contributor);


            RestClientExtension restClientExtensions = new RestClientExtension(_ckContainer, client, request);
            List<string> countResult = new List<string>();
            IRestResponse authentificationResult = restClientExtensions.PostQuery(urlAuth, proxy, parameters);
            if (authentificationResult.IsSuccessful)
            {
                var resp = restClientExtensions.PutQuery(query_str, proxy, data);
            }
            return RedirectToAction("GetTickets");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
