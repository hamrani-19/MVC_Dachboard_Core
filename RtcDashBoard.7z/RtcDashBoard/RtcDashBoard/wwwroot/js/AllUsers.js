﻿$(document).ready( function () {
    $('#allUsers').DataTable();
} );