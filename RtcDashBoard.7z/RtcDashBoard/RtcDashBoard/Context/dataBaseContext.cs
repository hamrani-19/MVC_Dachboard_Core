﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace RtcDashBoard.Models
{
    public partial class dataBaseContext : DbContext
    {
        public dataBaseContext()
        {
        }

        public dataBaseContext(DbContextOptions<dataBaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite("Filename=./DB/RtcDashBoard.db");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasIndex(e => e.RoleId)
                    .IsUnique();

                entity.HasIndex(e => e.RoleName)
                    .IsUnique();

                entity.Property(e => e.RoleId)
                    .HasColumnName("RoleID")
                    .ValueGeneratedNever();

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasColumnType("STRING");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.Das);

                entity.HasIndex(e => e.Email)
                    .IsUnique();

                entity.HasIndex(e => e.RoleId)
                    .IsUnique();

                entity.Property(e => e.Das)
                    .HasColumnName("DAS")
                    .HasColumnType("STRING")
                    .ValueGeneratedNever();

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasColumnType("BOOLEAN");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnType("STRING");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnType("STRING");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnType("STRING");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.HasOne(d => d.Role)
                    .WithOne(p => p.Users)
                    .HasForeignKey<Users>(d => d.RoleId)
                    .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}
