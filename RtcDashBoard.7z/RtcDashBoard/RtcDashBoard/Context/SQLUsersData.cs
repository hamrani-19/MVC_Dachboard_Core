﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RtcDashBoard.Models;

namespace RtcDashBoard.Context
{
    public class SQLUsersData
    {
        private dataBaseContext _context { get; set; }

        public SQLUsersData(dataBaseContext context)
        {
            _context = context;
        }

        public Users Get(string DAS)
        {
            return _context.Users.FirstOrDefault(e => e.Das == DAS);
        }

        public Role GetRole(Users user)
        {
            return _context.Role.FirstOrDefault(e => e.RoleId == user.RoleId);
        }
    }
        
}
