﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using RestSharp;

namespace RtcDashBoard.ClientServer
{
    public class RestClientExtension : RestClient
    {
        private CookieContainer _cookie;
        RestClient _client = new RestClient();
        RestRequest _request = new RestRequest();

        public RestClientExtension()
        {
          
        }
        public RestClientExtension(CookieContainer cookie, RestClient client, RestRequest request)
        {
            this._cookie = cookie;
            this._client = client;
            this._request = request;
            this._client.CookieContainer = this._cookie;

        }
        public IRestResponse PostQuery(string url, string proxy, Dictionary<string, string> dict)
        {
            try
            {
                IRestResponse response = null;
                this._client.BaseUrl = new Uri(url);
                //client.ConfigureWebRequest(wr => wr.Proxy = new WebProxy(proxy) { BypassProxyOnLocal = false });
                this._request = new RestRequest(Method.POST);

                if (dict != null)
                {
                    foreach (var item in dict)
                    {
                        this._request.AddParameter(item.Key, item.Value);
                    }
                }
                response = this._client.Execute(this._request);
                return response;

            }
            catch (Exception e)
            {
                Console.Out.WriteLine("-----------------");
                Console.Out.WriteLine(e.Message);
                return null;
            }
            finally
            { }
        }
        public IRestResponse GetQuery(string url, string proxy, Dictionary<string, string> dict = null)
        {
            try
            {
                IRestResponse response = null;
                this._client.BaseUrl = new Uri(url);
                //client.ConfigureWebRequest(wr => wr.Proxy = new WebProxy(proxy) { BypassProxyOnLocal = false });
                this._request = new RestRequest(Method.GET);
                this._request.AddHeader("Accept", "application/rdf+xml");
                this._request.AddHeader("OSLC-Core-Version", "2.0");

                if (dict != null)
                {
                    foreach (var item in dict)
                    {
                        this._request.AddParameter(item.Key, item.Value);
                    }
                }
                response = this._client.Execute(this._request);
                return response;

            }
            catch (Exception e)
            {
                Console.Out.WriteLine("-----------------");
                Console.Out.WriteLine(e.Message);
                return null;
            }
            finally
            { }
        }

    }
}
