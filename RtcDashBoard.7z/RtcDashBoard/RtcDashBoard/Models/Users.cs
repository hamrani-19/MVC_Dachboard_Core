﻿using System;
using System.Collections.Generic;

namespace RtcDashBoard.Models
{
    public partial class Users
    {
        public string Das { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Active { get; set; }
        public string Password { get; set; }
        public long? RoleId { get; set; }

        public virtual Role Role { get; set; }
    }
}
