﻿using System;
using System.Collections.Generic;

namespace RtcDashBoard.Models
{
    public partial class Role
    {
        public long RoleId { get; set; }
        public string RoleName { get; set; }

        public virtual Users Users { get; set; }
    }
}
